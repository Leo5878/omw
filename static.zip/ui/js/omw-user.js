let defaultUser = {
  url: "default user url",
};

let o1 = {
  title: "Окно",
  parseIn: "./content.html",
	el: "styleCombilyte",
};

let o2 = {
  url: "user o2",
  echo: "<h1><center>Hello World</center></h1>",
  title: "Open window",
};

const userVideo = {
  el: ['video leo juy'],
  video: {
    id: "",
	  url: "//www.w3schools.com/html/mov_bbb.mp4",
    type: "mp4",
    autoPlay: false,
    controls: true,
    height: null,
    width: "100%",
    poster: null,
    loop: false,
    muted: false,
    preload: false,
  },
};

const image = {
  img: true,
  url: "//sun1-3.userapi.com/c840629/v840629378/6edc5/SANLCQ6UDpA.jpg",
  alt: "",
  width: "100%",
  height: "",
};